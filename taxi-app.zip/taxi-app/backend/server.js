'use strict';
// Точка входа: HTTP-сервер, статика фронтенда, API, игровой цикл.
const http = require('http'), fs = require('fs'), path = require('path');
const { CITIES } = require('./src/cities');
const { World } = require('./src/sim');
const { createRouter } = require('./src/routes');

const IDS = ['paris', 'amsterdam', 'vienna', 'rome', 'london'];
const ROOT = path.join(__dirname, '..', 'frontend');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };

function serveStatic(res, pathname) {
  const f = path.normalize(path.join(ROOT, pathname === '/' ? 'index.html' : pathname));
  if (!f.startsWith(ROOT)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(f, (e, b) => {
    if (e) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' }); res.end(b);
  });
}

function start(port = +process.env.PORT || 3000, { speed = +process.env.SIM_SPEED || 1 } = {}) {
  const worlds = CITIES.map((c, i) => new World(IDS[i], c, { speed }));
  const handle = createRouter({ worlds, ids: IDS });
  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    if (await handle(req, res, url)) return;
    serveStatic(res, decodeURIComponent(url.pathname));
  });
  // Игровой цикл: тикают только города, где есть зрители или активные заказы.
  let last = Date.now(), n = 0;
  const loop = setInterval(() => {
    const now = Date.now(), dt = Math.min(.1, (now - last) / 1000); last = now; n++;
    for (const w of worlds) {
      if (!w.active) continue;
      w.tick(dt);
      if (n % 2 === 0 && w.subs.size) { const msg = `data: ${JSON.stringify(w.snapshot())}\n\n`; for (const r of w.subs) r.write(msg); }
    }
  }, 50);
  server.on('close', () => clearInterval(loop));
  return new Promise(ok => server.listen(port, () => ok(server)));
}

module.exports = { start };
if (require.main === module) {
  start().then(s => console.log(`Жёлтый такси: http://localhost:${s.address().port}  (SIM_SPEED=${process.env.SIM_SPEED || 1})`));
}
