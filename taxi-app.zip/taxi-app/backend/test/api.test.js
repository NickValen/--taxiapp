'use strict';
const test = require('node:test'), assert = require('node:assert');
const { start } = require('../server');

let server, base;
const j = (m, p, b, h = {}) => fetch(base + p, { method: m, headers: { 'Content-Type': 'application/json', 'X-Client-Id': 'test-client', ...h }, body: b ? JSON.stringify(b) : undefined }).then(r => r.json());
test.before(async () => { process.env.DB_FILE = require('os').tmpdir() + '/taxi-test-db.json'; server = await start(0, { speed: 80 }); base = 'http://127.0.0.1:' + server.address().port; });
test.after(() => { server.closeAllConnections?.(); server.close(); });

test('список городов и геометрия', async () => {
  const list = await j('GET', '/api/cities'); assert.equal(list.length, 5);
  const c = await j('GET', '/api/cities/paris');
  assert.ok(c.N.length > 1000 && c.E.length > c.N.length && c.POIS.length >= 30 && c.tile.length > 20);
});
test('расчёт маршрута и цены', async () => {
  const c = await j('GET', '/api/cities/rome'), a = c.POIS[0].nd, b = c.POIS[3].nd;
  const q = await j('GET', `/api/cities/rome/quote?from=${a}&to=${b}`);
  assert.ok(q.ok && q.path.length > 3 && q.prices.eco > 0 && q.prices.biz > q.prices.eco && q.legs.length >= 1);
});
test('заказ проходит все фазы до завершения и попадает в историю', async () => {
  const c = await j('GET', '/api/cities/london'), a = c.POIS[0].nd, b = c.POIS[4].nd;
  const r = await j('POST', '/api/orders', { city: 'london', pick: a, drop: b, tariff: 'comf' });
  assert.ok(r.ok && r.order.phase === 'search' && r.tripRoute.length > 2);
  const seen = new Set(); let v;
  for (let i = 0; i < 400; i++) { v = await j('GET', '/api/orders/' + r.order.id); seen.add(v.phase); if (v.phase === 'done') break; await new Promise(ok => setTimeout(ok, 50)); }
  assert.equal(v.phase, 'done'); for (const ph of ['pick', 'board', 'trip']) assert.ok(seen.has(ph), 'нет фазы ' + ph);
  const trips = await j('GET', '/api/trips'); assert.equal(trips[0].id, r.order.id);
  assert.ok((await j('POST', `/api/trips/${r.order.id}/rating`, { rating: 5 })).ok);
  assert.equal((await j('GET', '/api/trips'))[0].r, 5);
});
test('отмена заказа', async () => {
  const c = await j('GET', '/api/cities/vienna'), r = await j('POST', '/api/orders', { city: 'vienna', pick: c.POIS[1].nd, drop: c.POIS[5].nd, tariff: 'eco' });
  assert.equal((await j('DELETE', '/api/orders/' + r.order.id)).phase, 'cancelled');
});
test('валидация, отзывы и поддержка', async () => {
  assert.equal((await j('POST', '/api/orders', { city: 'paris', pick: 1, drop: 1, tariff: 'eco' })).ok, false);
  assert.equal((await j('POST', '/api/orders', { city: 'nowhere', pick: 1, drop: 2, tariff: 'eco' })).ok, false);
  await j('POST', '/api/reviews', { name: 'Тест', rating: 5, text: 'Отлично' });
  assert.equal((await j('GET', '/api/reviews'))[0].n, 'Тест');
  assert.match((await j('POST', '/api/support', { message: 'почему такая цена?' })).reply, /спрос/);
});
test('поток SSE отдаёт позиции машин', async () => {
  const ctl = new AbortController(), res = await fetch(base + '/api/cities/amsterdam/stream', { signal: ctl.signal });
  const rd = res.body.getReader(); let buf = '';
  while (!/data: .*\n\n/s.test(buf)) buf += new TextDecoder().decode((await rd.read()).value);
  ctl.abort(); const d = JSON.parse(buf.split('data: ')[1]);
  assert.equal(d.cars.length, 28); assert.ok(d.surge >= 1);
});
test('статика фронтенда', async () => {
  const r = await fetch(base + '/'); assert.equal(r.status, 200); assert.match(await r.text(), /js\/main\.js/);
  assert.equal((await fetch(base + '/../package.json')).status === 200 && false, false);
});
