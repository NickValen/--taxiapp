'use strict';
// Геометрия и генератор городов (районы, реки, парки, граф дорог, пробки, перекрытия, объекты).
// Код перенесён из одностраничного прототипа без изменений логики.
const PI=Math.PI,hyp=Math.hypot,ek=(a,b)=>a<b?a*8192+b:b*8192+a;
const mulberry=a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
const ell=(x0,y0,rx,ry,a0=0,a1=2*PI,p=2)=>{const n=Math.max(10,Math.ceil(Math.abs(a1-a0)*Math.max(rx,ry)/.22)),o=[];for(let i=0;i<=n;i++){const a=a0+(a1-a0)*i/n,c=Math.cos(a),s=Math.sin(a);o.push([x0+rx*Math.sign(c)*Math.abs(c)**(2/p),y0+ry*Math.sign(s)*Math.abs(s)**(2/p)])}return o};
const sg=(a,b)=>{const n=Math.max(1,Math.ceil(hyp(b[0]-a[0],b[1]-a[1])/.3)),o=[];for(let i=0;i<=n;i++)o.push([a[0]+(b[0]-a[0])*i/n,a[1]+(b[1]-a[1])*i/n]);return o};
function spl(P,st=.3){const o=[];for(let i=0;i<P.length-1;i++){const p0=P[Math.max(0,i-1)],p1=P[i],p2=P[i+1],p3=P[Math.min(P.length-1,i+2)],n=Math.max(2,Math.ceil(hyp(p2[0]-p1[0],p2[1]-p1[1])/st));for(let k=0;k<=(i===P.length-2?n:n-1);k++){const t=k/n,t2=t*t,t3=t2*t;o.push([0,1].map(c=>.5*(2*p1[c]+(-p0[c]+p2[c])*t+(2*p0[c]-5*p1[c]+4*p2[c]-p3[c])*t2+(-p0[c]+3*p1[c]-3*p2[c]+p3[c])*t3)))}}return o}
const pol=(c,d,r)=>[c[0]+Math.cos(d*PI/180)*r,c[1]+Math.sin(d*PI/180)*r];
const off=(P,d)=>P.map((p,i)=>{const a=P[Math.max(0,i-1)],b=P[Math.min(P.length-1,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],L=hyp(dx,dy)||1;return[p[0]-dy/L*d,p[1]+dx/L*d]});
function urban(rn,s){const R=[],Wt=s.water||[],nm=s.nm,ex=(s.ex||[]).concat((s.rb||[]).map(([x,y,,,l])=>[x,y,l*.8]));
 const dsg=(p,a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1],t=Math.max(0,Math.min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy||1)));return hyp(p[0]-a[0]-dx*t,p[1]-a[1]-dy*t)};
 const wd=(x,y)=>Wt.some(([pts,w])=>{for(let i=0;i<pts.length-1;i++)if(dsg([x,y],pts[i],pts[i+1])<w/2+.1)return true;return false});
 s.dis.forEach(([c0,c1,rx,ry,ang,sx,sy,ne],di)=>{const a=ang*PI/180,ca=Math.cos(a),sa=Math.sin(a),M=Math.max(rx,ry)*1.2,ph=rn()*6;
  for(let dir=0;dir<2;dir++){const sp=dir?sy:sx;let u=-M+rn()*sp,k=0;
   while(u<M){let run=[];const fl=()=>{if(run.length>1)R.push([nm[(k+di*3)%nm.length],k%6===3?1:2,run]);run=[]};
    for(let v=-M;v<=M;v+=.3){const lx=dir?v:u,ly=dir?u:v;let x=c0+lx*ca-ly*sa,y=c1+lx*sa+ly*ca;x+=Math.sin(y*.7+ph)*.12;y+=Math.cos(x*.6+ph)*.12;
     if(Math.abs(x-c0)<=rx&&Math.abs(y-c1)<=ry&&!wd(x,y)&&(ne||!ex.some(([a1,b1,r1])=>hyp(x-a1,y-b1)<r1)))run.push([x,y]);else fl()}
    fl();u+=sp*(.8+rn()*.4);k++}}});
 (s.art||[]).forEach(([n,c,p,raw])=>R.push([n,c,raw?p:spl(p)]));
 (s.rb||[]).forEach(([x,y,r,k,l,rot])=>{R.push(['Площадь',2,ell(x,y,r,r)]);for(let i=0;i<k;i++){const a=rot+i*360/k;R.push([nm[i%nm.length],1,sg(pol([x,y],a,r-.05),pol([x,y],a,l))])}});
 Wt.forEach(([pts,w,n,nb])=>{for(let b=1;b<=(nb||0);b++){const i=Math.floor(pts.length*(b/(nb+1))),a=pts[Math.max(0,i-1)],c=pts[Math.min(pts.length-1,i+1)],dx=c[0]-a[0],dy=c[1]-a[1],L=hyp(dx,dy)||1,nx=-dy/L,ny=dx/L,h=w/2+1.4,p=pts[i];R.push(['Мост №'+b,2,sg([p[0]-nx*h,p[1]-ny*h],[p[0]+nx*h,p[1]+ny*h])])}});
 return{R,water:Wt,isl:[],parks:s.parks||[],zones:s.zones||[],lm:s.lm}}
const DEFS=[
{n:'Париж',e:'🗼',d:'Сена, правый и левый берег, бульвары Османа',seed:5,p:2,f:rn=>urban(rn,{nm:['Улица Сен-Оноре','Улица Мира','Улица Лафайет','Улица Ренн','Улица Бонапарта','Улица Бак','Улица Севр','Улица Клиши','Улица Бретань','Улица Тюренн'],
 water:[[spl([[-1,7.4],[2.5,8],[5.5,7.2],[8.5,6.6],[11.5,7.1],[14.5,8.2],[17.5,7.7],[23,6.8]]),1,'Сена',7]],
 dis:[[11,3.6,10.6,3.5,-10,.8,.7],[11,10.6,10.6,3.6,6,.8,.72]],rb:[[5.4,3.6,.6,8,3.4,10]],
 art:[['Елисейские Поля',1,[[6,3.8],[9,4.5],[11.6,5.8]]],['Улица Риволи',1,[[9,5.9],[11.5,6.2],[14,7.1],[17,6.7]]],['Бульвар Сен-Жермен',1,[[7,8.6],[10,8],[13,8.9],[16,9.1],[19,8.6]]],['Большие бульвары',1,[[8,2.8],[11,2.5],[14,3.4],[17,4.6]]]],
 parks:[[3,2,1.6,1],[11.5,6.3,1,.25],[10.5,9.9,1.1,.7],[17,4,1.3,.8]],zones:[[11.5,5.4,3,1.6],[11,9.2,2.6,1.2]],
 lm:[[5.4,3.6,'🏛️','Триумфальная арка'],[4.2,8.4,'🗼','Эйфелева башня'],[11.2,6,'🖼️','Лувр'],[13.2,7,'⛪','Нотр-Дам'],[11.8,1.8,'🕌','Сакре-Кёр'],[9.8,5.4,'⛲','Площадь Согласия'],[15.6,3.4,'🚉','Северный вокзал'],[10.2,7.6,'🎨','Музей Орсе']]})},
{n:'Амстердам',e:'🚲',d:'Полукольца каналов вокруг центра, Амстел и залив IJ',seed:9,p:2,f:rn=>urban(rn,{nm:['Калверстрат','Лейдсестрат','Утрехтсестрат','Рембрандтстрат','Ниуве Зейдс','Вейзелстрат','Нес','Регулирсграхт','Ньивмаркт','Спуйстрат'],
 water:[[spl([[-1,13.6],[6,13.9],[11,13.4],[16,13.9],[23,13.5]]),1.5,'IJ',0],...['Сингел','Херенграхт','Кейзерсграхт','Принсенграхт'].map((n,i)=>[ell(11,13,2.6+i*.8,2.4+i*.76,PI*1.04,PI*1.96),.28,n,6]),[spl([[14.6,13.6],[14.2,11],[14.6,8],[15,5],[15.6,2]]),.5,'Амстел',3]],
 dis:[[11,7,10.8,6.9,0,.8,.7],[17.2,3.6,3.6,3,25,1,.9,1]],ex:[[17.2,3.6,3.7]],art:[['Дамрак',1,[[11,12.2],[11,10],[11,8],[10.8,5.5]]],['Амстелвеен',1,[[15.4,12],[15.2,8],[15.6,4]]]],
 parks:[[5.8,6.4,1.6,.9],[17.5,7,1.2,.8]],zones:[[11,10.2,2.6,2]],
 lm:[[11,12.4,'🚉','Центральный вокзал'],[10.9,10.3,'🏛️','Площадь Дам'],[8.9,10.9,'🏠','Дом Анны Франк'],[11.7,7.7,'🎨','Рейксмюзеум'],[9.6,8.9,'🎭','Лейдсеплейн'],[12.4,9.4,'☕','Рембрандтплейн'],[10.3,7.2,'🖼️','Музей Ван Гога'],[5.8,6.4,'🌳','Вондельпарк']]})},
{n:'Вена',e:'🎻',d:'Рингштрассе вокруг старого города и Гюртель',seed:13,p:2.4,f:rn=>urban(rn,{nm:['Грабен','Кёртнер штрассе','Ротентурмштрассе','Випплингерштрассе','Нусдорфер штрассе','Ландштрассер Хауптштрассе','Шоттенгассе','Верингер штрассе','Принц-Ойген-штрассе','Хернальсер Хауптштрассе'],
 water:[[spl([[7,-.5],[10.5,1.6],[14.2,2.8],[17.6,4.4],[23,4.6]]),.6,'Дунайский канал',4],[spl([[19.8,-1],[19.2,4],[20,9],[19.4,15]]),1.4,'Дунай',3]],
 dis:[[11,7,3.6,2.9,22,.5,.5,1],[11,7,10.8,6.9,-8,.8,.75]],ex:[[11,7,3.5]],
 art:[['Рингштрассе',1,ell(11,7,4.1,3.1,0,2*PI,3),1],['Гюртель',1,ell(11,7,7.8,5.3,0,2*PI,2.8),1],['Мариахильфер штрассе',1,[[.5,8.6],[4,8.2],[7,7.6],[9,7.2]]]],
 parks:[[12.2,9.6,1,.6],[4.4,10.2,1.8,1.1],[8,5.7,.9,.5]],zones:[[11,7,3.2,2.5]],
 lm:[[11,7,'⛪','Собор Св. Стефана'],[11,10,'🎭','Венская опера'],[8.9,7.3,'🏰','Хофбург'],[4.2,9.9,'🏰','Шёнбрунн'],[12.6,10.8,'🏛️','Бельведер'],[17.6,3.6,'🎡','Колесо обозрения'],[8,4.4,'🏛️','Ратуша'],[13.6,8.6,'🌳','Штадтпарк']]})},
{n:'Рим',e:'🏛️',d:'Тибр, плотная застройка и дорога к Колизею',seed:17,p:2,f:rn=>urban(rn,{nm:['Виа Национале','Виа Венето','Виа Систина','Виа Мерулана','Виа Ардеатина','Виа Номентана','Виа Салария','Виа Аурелия','Виа Кандия','Виа Ости'],
 water:[[spl([[7.8,-1],[8.6,1.6],[7.7,3.6],[8.6,5.8],[9.8,7.6],[9.2,10],[10.4,12.4],[11,15]]),.9,'Тибр',5]],
 dis:[[14.6,7,7,7.8,18,.62,.6],[3.8,7,4,7.8,-12,.7,.65]],
 art:[['Виа дель Корсо',1,[[10.6,2.8],[11.2,4.6],[11.8,6.4],[12.2,7.5]]],['Виа деи Фори Империали',1,[[12.2,7.5],[14,9.3]]],['Виа Кавур',1,[[14.4,9.3],[15.4,7.6],[16.6,6.2],[17.4,5.6]]],['Колизей',2,ell(14,9.8,.7,.55),1],['Виа делла Кончилиационе',1,[[3.8,4.6],[7.6,4.6],[9.4,4.7]]]],
 parks:[[14.8,2.4,1.5,1],[4.2,8.2,1.3,.9]],zones:[[12,5.8,2.6,2]],
 lm:[[2.9,4.6,'⛪','Площадь Св. Петра'],[7.6,4.6,'🏰','Замок Св. Ангела'],[10.6,2.4,'🌅','Пьяцца дель Пополо'],[12.2,7.5,'🏛️','Пьяцца Венеция'],[14,9.8,'🏟️','Колизей'],[10.4,5.7,'⛲','Пьяцца Навона'],[11,6.8,'🕍','Пантеон'],[17.4,5.6,'🚉','Вокзал Термини'],[12.6,5.6,'💧','Фонтан Треви']]})},
{n:'Лондон',e:'🎡',d:'Темза, парки и широкие улицы севера',seed:21,p:2.2,f:rn=>urban(rn,{nm:['Бейкер-стрит','Гауэр-стрит','Грейт-Портленд','Тоттенхэм-Корт','Кингсуэй','Фарингдон','Кромвель-роуд','Ламбет-роуд','Боро-Хай-стрит','Кеннингтон-роуд'],
 water:[[spl([[-1,8.6],[3,8],[5.5,9.2],[8,8.4],[10.4,7.6],[12.3,8.6],[14.6,8],[16.8,9.2],[19.4,8.6],[23,9.4]]),1.1,'Темза',6]],
 dis:[[11,4.4,10.8,4.4,-6,.9,.8],[11,11.2,10.6,3,10,.9,.8]],rb:[[5.4,5.6,.45,6,2.2,0],[9.4,5.4,.3,4,1.2,20]],
 art:[['Оксфорд-стрит',1,[[3.6,5],[7,4.9],[9.3,4.7],[12.2,5],[14.5,5.4]]],['Стрэнд',1,[[9.9,6.2],[11.6,6.5],[13.6,6.6],[15.4,6.5],[18,6.8]]],['Риджент-стрит',1,[[8.4,1.4],[8.9,3.2],[9.2,4.6],[9.5,5.6]]],['Юстон-роуд',1,[[4,2.6],[8.8,2.6],[12.2,2.4],[16,3.4],[19,4.2]]]],
 parks:[[3.6,4,2.1,1],[7.2,6.3,1,.45],[6.4,1.6,1.1,.8]],zones:[[10.8,5.6,3,1.4]],
 lm:[[9.6,7.1,'🕰️','Биг-Бен'],[9.9,6.2,'🦁','Трафальгарская пл.'],[9.4,5.4,'💡','Пикадилли-серкус'],[5.4,5.6,'🏛️','Хайд-парк-корнер'],[16.7,7.6,'🌉','Тауэрский мост'],[12.1,9.4,'🎡','Лондонский глаз'],[13.6,6.6,'⛪','Собор Св. Павла'],[7.4,6.3,'👑','Букингемский дворец']]})}];
const CATS=[['school','🏫','Школы'],['museum','🏺','Музеи'],['court','⚖️','Суды'],['shop','🛒','Магазины'],['mall','🏬','ТЦ'],['hotel','🏨','Отели'],['food','🍽️','Рестораны']];
const inT=(q,p,k=1)=>Math.abs(q[0]-11)<=10.7*k&&Math.abs(q[1]-7)<=6.7*k;
function gen(d){const rng=mulberry(d.seed),D=d.f(rng),pcs=[];
 D.R.forEach(([n,c,p],k)=>{let run=[];const fl=()=>{if(run.length>1)pcs.push({n,c,k,p:run});run=[]};for(const q of p){if(inT(q,d.p))run.push(q);else fl()}fl()});
 const lab=[],sL=new Set(),mk=(pc,w)=>{const i=pc.p.length>>1,a=pc.p[Math.max(0,i-1)],b=pc.p[Math.min(pc.p.length-1,i+1)];let an=Math.atan2(b[1]-a[1],b[0]-a[0]);if(an>PI/2)an-=PI;if(an<-PI/2)an+=PI;lab.push({t:pc.n,x:pc.p[i][0],y:pc.p[i][1],a:an,w})};
 pcs.slice().sort((a,b)=>b.p.length-a.p.length).forEach(pc=>{if(pc.c===1&&pc.p.length>9&&!sL.has(pc.n)&&lab.length<14){sL.add(pc.n);mk(pc,0)}});
 D.water.forEach(([pts,w,n2])=>{if(n2){const ins=pts.filter(q=>inT(q,d.p));if(ins.length>6)mk({n:n2,p:ins},1)}});
 const SG=[];pcs.forEach((pc,pi)=>{for(let i=0;i<pc.p.length-1;i++){const a=pc.p[i],b=pc.p[i+1];SG.push({pi,a,b,ins:[],x0:Math.min(a[0],b[0]),x1:Math.max(a[0],b[0]),y0:Math.min(a[1],b[1]),y1:Math.max(a[1],b[1])})}});
 const gh=new Map(),dn=new Set();SG.forEach((s,i)=>{for(let a=Math.floor(s.x0);a<=Math.floor(s.x1);a++)for(let b=Math.floor(s.y0);b<=Math.floor(s.y1);b++){const k=a*100+b;(gh.get(k)||gh.set(k,[]).get(k)).push(i)}});
 gh.forEach(L=>{for(let x=0;x<L.length;x++)for(let y=x+1;y<L.length;y++){const i=Math.min(L[x],L[y]),j=Math.max(L[x],L[y]),key=i*100000+j;if(dn.has(key))continue;dn.add(key);const A=SG[i],B=SG[j];if(A.pi===B.pi||A.x1<B.x0-.01||B.x1<A.x0-.01||A.y1<B.y0-.01||B.y1<A.y0-.01)continue;
  const rx=A.b[0]-A.a[0],ry=A.b[1]-A.a[1],sx=B.b[0]-B.a[0],sy=B.b[1]-B.a[1],den=rx*sy-ry*sx;if(Math.abs(den)<1e-9)continue;
  const t=((B.a[0]-A.a[0])*sy-(B.a[1]-A.a[1])*sx)/den,u=((B.a[0]-A.a[0])*ry-(B.a[1]-A.a[1])*rx)/den;
  if(t>=-.001&&t<=1.001&&u>=-.001&&u<=1.001){const x0=A.a[0]+rx*t,y0=A.a[1]+ry*t;A.ins.push([t,x0,y0]);B.ins.push([u,x0,y0])}}});
 const N=[],nmap=new Map(),node=(x,y)=>{const k=Math.round(x*25)+','+Math.round(y*25);let n=nmap.get(k);if(!n){n=[x,y,N.length];N.push(n);nmap.set(k,n)}return n};
 const edges=[],seen=new Set(),addE=(a,b,pc)=>{if(a===b)return;const k=ek(a[2],b[2]);if(seen.has(k))return;seen.add(k);edges.push({a:a[2],b:b[2],c:pc.c,n:pc.n,k:pc.k,l:hyp(a[0]-b[0],a[1]-b[1]),f:1,x:0})};
 const bs=new Map();SG.forEach(s=>{(bs.get(s.pi)||bs.set(s.pi,[]).get(s.pi)).push(s)});
 pcs.forEach((pc,pi)=>{let prev=null;for(const s of bs.get(pi)){const pts=[s.a,...s.ins.sort((u,v)=>u[0]-v[0]).map(q=>[q[1],q[2]]),s.b];for(const q of pts){const n=node(q[0],q[1]);if(prev)addE(prev,n,pc);prev=n}}});
 const par=N.map((_,i)=>i),fd=i=>par[i]===i?i:(par[i]=fd(par[i]));edges.forEach(e=>{par[fd(e.a)]=fd(e.b)});
 for(let it=0;it<30;it++){const cm=new Map();N.forEach((n,i)=>{const r=fd(i);(cm.get(r)||cm.set(r,[]).get(r)).push(i)});if(cm.size<2)break;const ar=[...cm.values()].sort((a,b)=>b.length-a.length);let best=null;
  for(const cp of ar.slice(1))for(const i of cp)for(const j of ar[0]){const dd=hyp(N[i][0]-N[j][0],N[i][1]-N[j][1]);if(!best||dd<best[0])best=[dd,i,j]}
  if(best[0]>1.6)break;edges.push({a:best[1],b:best[2],c:2,n:'проезд',k:-1,l:best[0],f:1,x:0});par[fd(best[1])]=fd(best[2])}
 const cnt=new Map();N.forEach((_,i)=>cnt.set(fd(i),(cnt.get(fd(i))||0)+1));let mr=0,mc=0;cnt.forEach((v,k)=>{if(v>mc){mc=v;mr=k}});
 const E=edges.filter(e=>fd(e.a)===mr),nl=N.filter((_,i)=>fd(i)===mr),adj=N.map(()=>[]),em=new Map();
 E.forEach(e=>{adj[e.a].push([e.b,e]);adj[e.b].push([e.a,e]);em.set(ek(e.a,e.b),e)});
 const nn=N.map((_,i)=>[...new Set(adj[i].map(([,e])=>e.n))].filter(x=>x!=='проезд').slice(0,2).join(' × ')||'проезд');
 const mid=e=>[(N[e.a][0]+N[e.b][0])/2,(N[e.a][1]+N[e.b][1])/2];
 const zone=(r,f)=>{const c=nl[(rng()*nl.length)|0];E.forEach(e=>{const m=mid(e);if(hyp(m[0]-c[0],m[1]-c[1])<r)e.f=Math.max(e.f,f)})};
 for(let k=0;k<3;k++)zone(1,3.2);for(let k=0;k<3;k++)zone(.8,1.8);
 const closedE=[];
 for(let t=0;t<700&&closedE.length<3;t++){const e0=E[(rng()*E.length)|0];if(e0.k<0||adj[e0.a].length<3&&adj[e0.b].length<3&&t<350)continue;const m=mid(e0),grp=E.filter(e=>!e.x&&e.k===e0.k&&hyp(mid(e)[0]-m[0],mid(e)[1]-m[1])<.3);if(!grp.length)continue;grp.forEach(e=>e.x=1);
  const sn=new Uint8Array(N.length),q=[nl[0][2]];sn[q[0]]=1;let cn=0;while(q.length){const u=q.pop();cn++;for(const[v,e]of adj[u])if(!e.x&&!sn[v]){sn[v]=1;q.push(v)}}
  if(cn<nl.length)grp.forEach(e=>e.x=0);else{closedE.push({g:grp,p:m});grp.forEach(e=>e.f=1)}}
 const tile=[],rc_=.7;[[1,1,0],[-1,1,90],[-1,-1,180],[1,-1,270]].forEach(([sx,sy,a0])=>{for(let k=0;k<=8;k++){const a=(a0+k*90/8)*PI/180;tile.push([11+sx*(10.7-rc_)+Math.cos(a)*rc_,7+sy*(6.7-rc_)+Math.sin(a)*rc_])}});
 const nearN=(x,y)=>{let b=null,bd=1e9;for(const n of nl){const dd=hyp(n[0]-x,n[1]-y);if(dd<bd){bd=dd;b=n}}return b};
 const POIS=D.lm.map(([x,y,e,n])=>{const nd=nearN(x,y);return{x:nd[0],y:nd[1],e,n,nd}}),STOPS=[];
 for(let t=0;t<500&&STOPS.length<9;t++){const n=nl[(rng()*nl.length)|0];if(adj[n[2]].length!==2||nn[n[2]]==='проезд'||[...STOPS,...POIS].some(p=>hyp(p.x-n[0],p.y-n[1])<1.8))continue;STOPS.push({x:n[0],y:n[1],e:'🚏',n:'Остановка «'+nn[n[2]]+'»',nd:n})}
 const CATP=[['school','🏫',['Школа №12','Гимназия №3','Лицей №7','Школа №45']],['museum','🏺',['Городской музей','Музей науки','Художественная галерея','Музей транспорта']],['court','⚖️',['Городской суд','Арбитражный суд']],['shop','🛒',['Супермаркет','Универмаг','Книжный магазин','Магазин одежды','Пекарня','Магазин электроники']],['mall','🏬',['ТЦ «Северный»','ТЦ «Мега»','ТЦ «Галерея»']],['hotel','🏨',['Гранд-отель','Отель «Центральный»','Отель «Парк»','Хостел «Уют»']],['food','🍽️',['Ресторан «Старый город»','Кафе «Уют»','Траттория','Бистро','Ресторан «Река»']]];
 CATP.forEach(([cat,e,names])=>names.forEach(n=>{for(let t=0;t<400;t++){const nd=nl[(rng()*nl.length)|0];if(adj[nd[2]].length<3&&t<300)continue;if([...STOPS,...POIS].some(p=>hyp(p.x-nd[0],p.y-nd[1])<1.1))continue;POIS.push({x:nd[0],y:nd[1],e,n,nd,cat,m:1});break}}));
 const hk=(i,j)=>i*100+j,H2=new Map();E.forEach(e=>{const a=N[e.a],b=N[e.b];for(let i=Math.floor(Math.min(a[0],b[0])-1);i<=Math.floor(Math.max(a[0],b[0])+1);i++)for(let j=Math.floor(Math.min(a[1],b[1])-1);j<=Math.floor(Math.max(a[1],b[1])+1);j++){const k=hk(i,j);(H2.get(k)||H2.set(k,[]).get(k)).push(e)}});
 const ds=(p,a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1],t=Math.max(0,Math.min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy||1)));return hyp(p[0]-a[0]-dx*t,p[1]-a[1]-dy*t)};
 const WS=[];D.water.forEach(([pts,w])=>{for(let i=0;i<pts.length-1;i++)WS.push([pts[i],pts[i+1],w/2+.12])});
 const bld=[[],[],[]],trees=[];
 for(let x=.2;x<0;x+=.42)for(let y=.2;y<14;y+=.42){const p=[x+(rng()-.5)*.25,y+(rng()-.5)*.25];if(!inT(p,d.p,.96))continue;let best=1e9,ang=0;
  for(const e of H2.get(hk(Math.floor(p[0]),Math.floor(p[1])))||[]){const dd=ds(p,N[e.a],N[e.b])-(e.c===1?.16:.1);if(dd<best){best=dd;ang=Math.atan2(N[e.b][1]-N[e.a][1],N[e.b][0]-N[e.a][0])}}
  if(best<.14||best>1.4||WS.some(([a,b,r])=>ds(p,a,b)<r)||D.parks.some(([px,py,rx,ry])=>((p[0]-px)/(rx+.1))**2+((p[1]-py)/(ry+.1))**2<1))continue;
  bld[(rng()*3)|0].push([p[0],p[1],.2+rng()*.16,.2+rng()*.12,Math.cos(ang),Math.sin(ang)])}
 D.parks.forEach(([px,py,rx,ry])=>{for(let k=0;k<9;k++)trees.push([px+(rng()-.5)*rx*1.6,py+(rng()-.5)*ry*1.6])});
 const xs=tile.map(q=>q[0]),ys=tile.map(q=>q[1]);
 return{n:d.n,e:d.e,d:d.d,N,nl,E,adj,em,nn,POIS,STOPS,water:D.water,isl:D.isl,parks:D.parks,trees,bld,tile,closedE,zones:D.zones||[],labels:lab,e1:E.filter(e=>e.c===1),e2:E.filter(e=>e.c!==1),th:E.filter(e=>e.f>=2.5),tm:E.filter(e=>e.f>1.4&&e.f<2.5),nTraf:6,bb:[Math.min(...xs),Math.min(...ys),Math.max(...xs),Math.max(...ys)]}}
const CITIES=DEFS.map(gen);

const r2 = v => Math.round(v * 100) / 100, pt = q => [r2(q[0]), r2(q[1])];

// Компактный JSON для клиента: граф дорог + всё, что нужно для отрисовки.
function serialize(c, id) {
  const names = [], ix = new Map();
  const ni = s => { if (!ix.has(s)) { ix.set(s, names.length); names.push(s); } return ix.get(s); };
  return {
    id, n: c.n, e: c.e, d: c.d,
    N: c.N.map(pt), names, nn: c.nn.map(ni),
    E: c.E.map(e => [e.a, e.b, e.c, e.f, e.x]),
    water: c.water.map(([p, w, nm]) => [p.map(pt), w, nm || '']),
    isl: c.isl, parks: c.parks, zones: c.zones,
    trees: c.trees.map(pt), tile: c.tile.map(pt),
    labels: c.labels.map(l => ({ t: l.t, x: r2(l.x), y: r2(l.y), a: r2(l.a), w: l.w })),
    closed: c.closedE.map(z => ({ g: z.g.map(e => [e.a, e.b]), p: pt(z.p) })),
    POIS: c.POIS.map(p => ({ e: p.e, n: p.n, nd: p.nd[2], cat: p.cat, m: p.m })),
    STOPS: c.STOPS.map(p => ({ e: p.e, n: p.n, nd: p.nd[2] })),
    bb: c.bb, stats: { pois: c.POIS.length, traf: c.nTraf, closed: c.closedE.length }
  };
}

module.exports = { CITIES, ek, serialize };
