'use strict';
// REST API + поток событий (SSE) с позициями машин.
const zlib = require('zlib');
const store = require('./store'), support = require('./support');
const { serialize } = require('./cities');

function createRouter({ worlds, ids }) {
  const orders = new Map();                 // id -> { w, o }
  const cityJson = {};                      // кеш gzip-JSON городов
  const ORDER_TTL = 10 * 60 * 1000;
  setInterval(() => { const now = Date.now(); for (const [id, { o }] of orders) if (now - (o.doneAt || o.created) > ORDER_TTL && (o.phase === 'done' || o.phase === 'cancelled')) orders.delete(id); }, 60000).unref();

  const json = (res, code, obj, extra = {}) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', ...extra }); res.end(JSON.stringify(obj)); };
  const body = req => new Promise((ok, no) => {
    let d = ''; req.on('data', c => { d += c; if (d.length > 1e5) { req.destroy(); no(new Error('too large')); } });
    req.on('end', () => { try { ok(d ? JSON.parse(d) : {}); } catch (e) { no(e); } });
  });
  const cid = req => String(req.headers['x-client-id'] || 'anon').slice(0, 64);

  worlds.forEach(w => { w.onDone = (o, world) => store.addTrip(o.clientId, {
    id: o.id, c: world.city.n, a: o.pick[2], b: o.drop[2], la: world.label(o.pick), lb: world.label(o.drop), p: o.price, r: 0,
    d: new Date().toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }) }); });

  return async function handle(req, res, url) {
    const p = url.pathname, m = req.method; let g;
    if (m === 'OPTIONS') { res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type, X-Client-Id', 'Access-Control-Allow-Methods': 'GET,POST,DELETE' }); res.end(); return true; }
    res.setHeader('Access-Control-Allow-Origin', '*');
    try {
      if (p === '/api/health') return json(res, 200, { ok: true, cities: ids.length }), true;
      if (p === '/api/cities' && m === 'GET')
        return json(res, 200, worlds.map(w => ({ id: w.id, n: w.city.n, e: w.city.e, d: w.city.d, pois: w.city.POIS.length }))), true;

      if ((g = p.match(/^\/api\/cities\/(\w+)$/)) && m === 'GET') {
        const w = worlds.find(x => x.id === g[1]); if (!w) return json(res, 404, { error: 'city not found' }), true;
        const buf = cityJson[w.id] || (cityJson[w.id] = zlib.gzipSync(JSON.stringify(serialize(w.city, w.id))));
        const gz = /gzip/.test(req.headers['accept-encoding'] || '');
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', ...(gz ? { 'Content-Encoding': 'gzip' } : {}) });
        res.end(gz ? buf : zlib.gunzipSync(buf)); return true;
      }
      if ((g = p.match(/^\/api\/cities\/(\w+)\/(stream|quote|rush)$/))) {
        const w = worlds.find(x => x.id === g[1]); if (!w) return json(res, 404, { error: 'city not found' }), true;
        if (g[2] === 'stream' && m === 'GET') {
          res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
          res.write('retry: 1000\n\n'); w.subs.add(res); req.on('close', () => w.subs.delete(res)); return true;
        }
        if (g[2] === 'quote' && m === 'GET') {
          const from = +url.searchParams.get('from'), to = url.searchParams.has('to') ? +url.searchParams.get('to') : null;
          return json(res, 200, w.quote(from, to)), true;
        }
        if (g[2] === 'rush' && m === 'POST') { const b = await body(req); w.rush = !!b.on; return json(res, 200, { rush: w.rush }), true; }
      }

      if (p === '/api/orders' && m === 'POST') {
        const b = await body(req), w = worlds.find(x => x.id === b.city);
        if (!w) return json(res, 400, { ok: false, error: 'city not found' }), true;
        const r = w.createOrder(cid(req), b.pick | 0, b.drop | 0, b.tariff);
        if (r.error) return json(res, 400, { ok: false, error: r.error }), true;
        orders.set(r.order.id, { w, o: r.order });
        return json(res, 201, { ok: true, order: w.view(r.order), tripRoute: r.tripRoute }), true;
      }
      if ((g = p.match(/^\/api\/orders\/([\w-]+)$/))) {
        const e = orders.get(g[1]); if (!e) return json(res, 404, { error: 'order not found' }), true;
        if (m === 'GET') return json(res, 200, e.w.view(e.o)), true;
        if (m === 'DELETE') { e.w.cancel(e.o); return json(res, 200, e.w.view(e.o)), true; }
      }

      if (p === '/api/trips' && m === 'GET') return json(res, 200, store.trips(cid(req))), true;
      if ((g = p.match(/^\/api\/trips\/([\w-]+)\/rating$/)) && m === 'POST') {
        const b = await body(req); return json(res, 200, { ok: store.rateTrip(cid(req), g[1], b.rating) }), true;
      }
      if (p === '/api/reviews' && m === 'GET') return json(res, 200, store.reviews()), true;
      if (p === '/api/reviews' && m === 'POST') { store.addReview(await body(req)); return json(res, 201, { ok: true }), true; }
      if (p === '/api/faq' && m === 'GET') return json(res, 200, support.FAQ), true;
      if (p === '/api/support' && m === 'POST') { const b = await body(req); return json(res, 200, { reply: support.reply(String(b.message || '').slice(0, 500)) }), true; }
    } catch (e) {
      json(res, 400, { error: String(e.message || e) }); return true;
    }
    if (p.startsWith('/api/')) return json(res, 404, { error: 'not found' }), true;
    return false;
  };
}
module.exports = { createRouter };
