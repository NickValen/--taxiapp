'use strict';
// Простое хранилище в JSON-файле: отзывы (общие) и история поездок (по клиентам).
const fs = require('fs'), path = require('path');
const FILE = process.env.DB_FILE || path.join(__dirname, '..', 'data', 'db.json');
const SEED = [
  { n: 'Мария', r: 5, t: 'Водитель приехал раньше, в машине чисто и тепло.' },
  { n: 'Олег', r: 4, t: 'Цена в час пик выросла, но доехали быстро.' },
  { n: 'Анна', r: 5, t: 'Удобно, что весь маршрут виден заранее.' }
];
let db = { reviews: SEED, trips: {} };
try { db = Object.assign(db, JSON.parse(fs.readFileSync(FILE, 'utf8'))); } catch (e) { /* первый запуск */ }

let timer;
function save() {
  clearTimeout(timer);
  timer = setTimeout(() => {
    try { fs.mkdirSync(path.dirname(FILE), { recursive: true }); fs.writeFileSync(FILE, JSON.stringify(db)); }
    catch (e) { console.error('db save failed:', e.message); }
  }, 400);
  timer.unref();
}
const clip = (s, n) => String(s || '').slice(0, n);

module.exports = {
  reviews: () => db.reviews.slice(0, 100),
  addReview({ name, rating, text }) {
    db.reviews.unshift({ n: clip(name, 40) || 'Гость', r: Math.min(5, Math.max(1, rating | 0)), t: clip(text, 500) || 'Без комментария' });
    db.reviews = db.reviews.slice(0, 200); save();
  },
  trips: cid => (db.trips[cid] || []).slice(0, 100),
  addTrip(cid, trip) { (db.trips[cid] = db.trips[cid] || []).unshift(trip); save(); },
  rateTrip(cid, id, r) { const t = (db.trips[cid] || []).find(x => x.id === id); if (t) { t.r = Math.min(5, Math.max(1, r | 0)); save(); } return !!t; }
};
