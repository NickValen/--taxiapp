'use strict';
// Серверная симуляция: парк машин, подбор водителя, поездки, пробки, динамическая цена.
const { randomUUID } = require('crypto');
const { ek } = require('./cities');

const hyp = Math.hypot, rd = v => Math.round(v * 1000) / 1000;
const TARIFFS = { eco: { b: 99, k: 22 }, comf: { b: 149, k: 30 }, biz: { b: 249, k: 46 } };
const DRIVERS = ['Артём','Максим','Ирина','Давид','Сергей','Олег','Мария','Никита','Тимур','Елена','Павел','Руслан','Анна','Игорь','Вика','Лев'];
const MODELS = ['Skoda Octavia','Kia Rio','Toyota Camry','Hyundai Solaris','VW Polo','Renault Logan'];
const FLEET = 28, FREE_SPEED = .35, BUSY_SPEED = .45;
const man = (a, b) => hyp(a[0] - b[0], a[1] - b[1]) * 1.3;   // «дорожное» расстояние по прямой
const etaMin = d => Math.max(1, Math.ceil(d * .55));
const rint = n => Math.random() * n | 0;

class World {
  constructor(id, city, { speed = 1, onDone } = {}) {
    this.id = id; this.city = city; this.speed = speed; this.onDone = onDone;
    this.rush = false; this.botT = 0;
    this.subs = new Set();        // SSE-клиенты
    this.waiting = new Set();     // заказы в поиске водителя
    this.names = new Map([...city.POIS, ...city.STOPS].map(p => [p.nd[2], p.n]));
    this.cars = Array.from({ length: FLEET }, (_, i) => {
      const n = this.rnd();
      return { id: i, x: n[0], y: n[1], a: 0, n, path: [], state: 'free', order: null, speed: 0, hold: 0,
        name: DRIVERS[i % DRIVERS.length], model: MODELS[rint(MODELS.length)], plate: 'А' + (100 + rint(900)) + 'ВК', rate: (4.6 + Math.random() * .4).toFixed(1) };
    });
    for (let i = 0; i < 3; i++) this.spawnBot();
  }
  get active() { return this.subs.size > 0 || this.waiting.size > 0 || this.cars.some(c => c.order && !c.order.bot); }
  rnd() { const nl = this.city.nl; return nl[rint(nl.length)]; }
  label(n) { return this.names.get(n[2]) || this.city.nn[n[2]] || 'проезд'; }

  // --- маршрутизация: Дейкстра с учётом пробок; перекрытые дороги пропускаются
  route(a, b) {
    const s = a[2], t = b[2]; if (s === t) return [];
    const { N, adj } = this.city, n = N.length;
    const D = new Float64Array(n).fill(1e9), Pv = new Int32Array(n).fill(-1), dn = new Uint8Array(n), open = [s]; D[s] = 0;
    while (open.length) {
      let bi = 0; for (let k = 1; k < open.length; k++) if (D[open[k]] < D[open[bi]]) bi = k;
      const u = open.splice(bi, 1)[0]; if (dn[u]) continue; dn[u] = 1; if (u === t) break;
      for (const [v, e] of adj[u]) {
        if (e.x || dn[v]) continue;
        const nd = D[u] + e.l * (1 + (e.f - 1) * .5);
        if (nd < D[v]) { D[v] = nd; Pv[v] = u; open.push(v); }
      }
    }
    if (Pv[t] < 0) return [];
    const p = []; for (let v = t; v !== s; v = Pv[v]) p.push(N[v]); return p.reverse();
  }
  edgeF(a, b) { const e = this.city.em.get(ek(a[2], b[2])); return e ? e.f : 1; }
  segF(c) { return c.path.length ? this.edgeF(c.n, c.path[0]) : 1; }
  len(c) {   // оставшийся путь, взвешенный пробками
    let t = 0, x = c.x, y = c.y, p = c.n;
    for (const q of c.path) { t += hyp(q[0] - x, q[1] - y) * this.edgeF(p, q); x = q[0]; y = q[1]; p = q; }
    return t;
  }
  start(c) { return c.path.length ? c.path[0] : c.n; }
  nearest(pick) {
    let best = null, bd = 1e9;
    for (const c of this.cars) {
      if (c.state !== 'free') continue;
      const s = this.start(c), d = hyp(c.x - s[0], c.y - s[1]) + hyp(s[0] - pick[0], s[1] - pick[1]) * 1.3;
      if (d < bd) { bd = d; best = c; }
    }
    return best && { c: best, d: bd };
  }
  dispatch(o) {
    const f = this.nearest(o.pick); if (!f) return false;
    const c = f.c, s = this.start(c);
    c.state = 'pick'; c.order = o;
    c.path = (c.path.length ? [s] : []).concat(this.route(s, o.pick));
    o.car = c; o.phase = 'pick'; o.tot = Math.max(.5, this.len(c));
    return true;
  }
  surge() {
    const b = this.cars.filter(c => c.state !== 'free').length / this.cars.length;
    return Math.min(2.9, Math.max(1, Math.round((1 + Math.max(0, b - .4) * 3.5) * 10) / 10));
  }
  price(tariff, d) { const t = TARIFFS[tariff]; return Math.round((t.b + t.k * d * .45) * this.surge() / 10) * 10; }

  // --- пошаговая симуляция
  step(c, dt) {
    let d = c.speed * dt;
    while (d > 0 && c.path.length) {
      const q = c.path[0], dx = q[0] - c.x, dy = q[1] - c.y, L = hyp(dx, dy);
      if (L <= d) { c.x = q[0]; c.y = q[1]; c.n = q; c.path.shift(); d -= L; }
      else { c.x += dx / L * d; c.y += dy / L * d; c.a = Math.atan2(dy, dx); d = 0; }
    }
  }
  startTrip(c) { const o = c.order; c.state = 'trip'; c.path = this.route(c.n, o.drop); o.phase = 'trip'; o.tot = Math.max(1, this.len(c)); }
  arrive(c) {
    const o = c.order;
    if (c.state === 'pick') { c.state = 'board'; c.hold = o.bot ? 1.5 : 4; o.phase = 'board'; }
    else if (c.state === 'trip') {
      c.state = 'free'; c.order = null; o.phase = 'done'; o.doneAt = Date.now();
      if (!o.bot && this.onDone) this.onDone(o, this);
    }
  }
  tick(dt) {
    dt *= this.speed;
    for (const c of this.cars) {
      c.speed = (c.state === 'free' ? FREE_SPEED : c.state === 'board' ? 0 : BUSY_SPEED) / this.segF(c);
      if (c.state === 'board') { c.hold -= dt; if (c.hold <= 0) this.startTrip(c); continue; }
      if (c.state === 'free' && !c.path.length) c.path = this.route(c.n, this.rnd());
      this.step(c, dt);
      if (!c.path.length) this.arrive(c);
    }
    this.botT += dt; if (this.botT > (this.rush ? 1.1 : 5)) { this.botT = 0; this.spawnBot(); }
    for (const o of this.waiting) { o.wait += dt; if (o.wait > 1.4 && this.dispatch(o)) this.waiting.delete(o); }
  }
  spawnBot() {
    if (this.cars.filter(c => c.state === 'free').length < 2) return;
    const a = this.rnd(), b = this.rnd(); if (man(a, b) < 4) return;
    this.dispatch({ bot: true, pick: a, drop: b });
  }

  // --- описание маршрута по улицам
  legsOf(a, b) {
    const P = [a, ...this.route(a, b)], R = [], em = this.city.em; let i = 1;
    while (i < P.length) {
      const e0 = em.get(ek(P[i - 1][2], P[i][2])); let j = i, len = 0, m = 1;
      while (j < P.length) { const e = em.get(ek(P[j - 1][2], P[j][2])); if (j > i && e.k !== e0.k) break; len += e.l; m = Math.max(m, e.f); j++; }
      R.push({ n: e0.n, len, m, end: P[j - 1][2] }); i = j;
    }
    const M = []; let pd = null;
    R.forEach((r, k) => { if (pd) { r.len += pd.len; r.m = Math.max(r.m, pd.m); pd = null; } if (r.len < .4 && k < R.length - 1) pd = r; else M.push(r); });
    const legs = M.map(r => `По ${r.n} · ${(r.len * .3).toFixed(1)} км${r.m >= 2.5 ? ' · 🔴 пробка' : r.m > 1.4 ? ' · 🟠 затор' : ''}`);
    legs.push('Прибытие: ' + this.label(b));
    return { legs, ends: M.map(r => r.end) };
  }
  pts(list) { return list.map(q => [rd(q[0]), rd(q[1])]); }

  // --- публичные операции
  quote(from, to) {
    const f = this.city.N[from]; if (!f) return { ok: false, error: 'bad node' };
    const nr = this.nearest(f), out = { surge: this.surge(), eta: nr ? etaMin(nr.d) : null, free: this.cars.filter(c => c.state === 'free').length };
    if (to == null) return out;
    const t = this.city.N[to]; if (!t) return { ok: false, error: 'bad node' };
    const path = this.route(f, t); if (!path.length) return { ...out, ok: false };
    const d = man(f, t), g = this.legsOf(f, t);
    return { ...out, ok: true, dist: rd(d), prices: Object.fromEntries(Object.keys(TARIFFS).map(k => [k, this.price(k, d)])), path: this.pts([f, ...path]), legs: g.legs };
  }
  createOrder(clientId, pick, drop, tariff) {
    const N = this.city.N, a = N[pick], b = N[drop];
    if (!a || !b || pick === drop || !TARIFFS[tariff]) return { error: 'bad request' };
    const path = this.route(a, b); if (!path.length) return { error: 'no route' };
    const g = this.legsOf(a, b);
    const o = { id: randomUUID(), clientId, pick: a, drop: b, tariff, price: this.price(tariff, man(a, b)), phase: 'search', wait: 0, car: null, tot: 1, legs: g.legs, ends: g.ends, bot: false, created: Date.now() };
    this.waiting.add(o);
    return { order: o, tripRoute: this.pts([a, ...path]) };
  }
  cancel(o) {
    if (o.phase === 'done' || o.phase === 'cancelled') return;
    if (o.car) { o.car.state = 'free'; o.car.order = null; o.car.path = o.car.path.slice(0, 1); }
    this.waiting.delete(o); o.phase = 'cancelled';
  }
  view(o) {
    const c = o.car, r = c ? this.len(c) : 0, ph = o.phase;
    const ks = new Set(c ? c.path.map(q => q[2]) : []), ci = o.ends.findIndex(x => ks.has(x));
    return {
      id: o.id, phase: ph, tariff: o.tariff, price: o.price, pick: o.pick[2], drop: o.drop[2], legs: o.legs, wait: rd(o.wait),
      legIndex: ph === 'trip' ? (ci < 0 ? o.legs.length - 1 : ci) : -1,
      eta: c ? etaMin(r) : null,
      progress: c ? (ph === 'board' ? 1 : Math.max(0, Math.min(1, 1 - r / o.tot))) : 0,
      driver: c ? { id: c.id, name: c.name, model: c.model, plate: c.plate, rate: c.rate } : null,
      route: c ? this.pts([[c.x, c.y], ...c.path]) : []
    };
  }
  snapshot() {
    const code = { free: 0, pick: 1, board: 2, trip: 3 };
    return {
      t: Date.now(), free: this.cars.filter(c => c.state === 'free').length, total: this.cars.length, surge: this.surge(), rush: this.rush,
      cars: this.cars.map(c => [c.id, rd(c.x), rd(c.y), rd(c.a), rd(c.speed * this.speed), code[c.state]])
    };
  }
}
module.exports = { World, TARIFFS };
