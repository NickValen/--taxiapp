// Левая панель: страницы (заказ, поездки, отзывы, поддержка, настройки) и общение с сервером.
const seg=(t,k,o)=>`<div class="lb">${t}</div><div class="seg">${o.map(([v,x])=>`<button class="${cfg[k]===v?'on':''}" data-set="${k}:${v}">${x}</button>`).join('')}</div>`;
const PAGES={
 trips:()=>`<h1>Поездки</h1><p class="sub">Всего поездок: ${hist.length}</p>${hist.map((h,i)=>`<div class="card"><b>${h.la}</b><br><small>→ ${h.lb} · ${h.c}</small><div class="row"><span>${h.p} ₽ · ${h.d}</span><span class="stars">${h.r?star(h.r):'без оценки'}</span></div>${h.c===CITY.n?`<button class="lnk" data-rep="${i}">Повторить маршрут</button>`:''}</div>`).join('')}`,
 reviews:()=>{const avg=(reviews.reduce((x,r)=>x+r.r,0)/reviews.length).toFixed(1);return `<h1>Отзывы</h1><p class="sub">Оценка сервиса ${avg} ★ · отзывов: ${reviews.length}</p>
<div class="card"><b>Ваш отзыв</b><div class="rs">${[1,2,3,4,5].map(n=>`<button class="st${ui.rs>=n?' on':''}" data-rs="${n}" aria-label="Оценка ${n}">★</button>`).join('')}</div><textarea id="rt" rows="3" placeholder="Как прошла поездка?">${esc(ui.rtext)}</textarea><button class="go" data-act="rsend" ${ui.rs?'':'disabled'}>Отправить отзыв</button></div>
${reviews.map(r=>`<div class="card"><b>${esc(r.n)}</b> <span class="stars">${star(r.r)}</span><p>${esc(r.t)}</p></div>`).join('')}`},
 support:()=>`<h1>Поддержка</h1><p class="sub">Частые вопросы и чат с помощником</p>${FAQ.map(([q,a])=>`<details><summary>${q}</summary><p>${a}</p></details>`).join('')}
<h3>Чат</h3><div class="chat">${chat.map(m=>`<div class="m${m.b?' b':''}">${esc(m.t)}</div>`).join('')}</div>
<div class="send"><input id="ct" placeholder="Напишите сообщение" autocomplete="off"><button class="go" data-act="csend">Отправить</button></div>`,
 settings:()=>`<h1>Настройки</h1><p class="sub">Сохраняются на этом устройстве</p><label class="lb">Имя<input id="nm" value="${esc(cfg.name)}" maxlength="20"></label>
${seg('Тема','theme',[['auto','Авто'],['light','Светлая'],['dark','Тёмная']])}${seg('Оплата','pay',[['Карта','Карта'],['Наличные','Наличные']])}
<div class="row tg"><span>Уведомления о поездке</span><button class="sw${cfg.notify?' on':''}" data-set="notify:t" role="switch" aria-checked="${cfg.notify}" aria-label="Уведомления"><i></i></button></div>`};

let tt;
function toast(t) { if (!cfg.notify || !t) return; const e = $('#ts'); e.textContent = t; e.classList.add('show'); clearTimeout(tt); tt = setTimeout(() => e.classList.remove('show'), 3500); }
function phToast(o) {
  if (o.phase === ui.ph) return; ui.ph = o.phase;
  toast({ pick: 'Водитель найден и едет к вам', board: 'Водитель на месте', trip: 'Поездка началась', done: 'Вы приехали' }[o.phase]);
}
function updHud() {
  $('#hf').textContent = stats.free + ' из ' + stats.total;
  const hs = $('#hs'); hs.textContent = 'спрос ×' + stats.surge.toFixed(1); hs.classList.toggle('hot', stats.surge > 1);
  const r = $('#rush'); r.classList.toggle('hot', !!stats.rush); r.setAttribute('aria-pressed', !!stats.rush);
}
const refresh = () => { if (ui.page === 'home') render(); };

// --- расчёт маршрута и цены на сервере
let qTok = 0;
async function fetchQuote() {
  if (!ui.pick || ui.order) return;
  const tok = ++qTok, pk = ui.pick, dr = ui.drop;
  try {
    const q = await api('GET', `/cities/${CITY.id}/quote?from=${pk[2]}${dr ? '&to=' + dr[2] : ''}`);
    if (tok !== qTok || ui.order) return;
    if (dr && !q.ok) { toast('Сюда нет проезда'); ui.drop = null; ui.quote = null; render(); return; }
    ui.quote = q; upd();
  } catch (e) { /* сервер недоступен */ }
}
function setPoint(n) {
  if (ui.order || !n) return;
  if (!ui.pick || ui.drop) { ui.pick = n; ui.drop = null; } else if (man(n, ui.pick) >= 4) ui.drop = n;
  ui.quote = null; render(); fetchQuote();
}

// --- действия
async function startOrder() {
  if (!(ui.pick && ui.drop && ui.quote && ui.quote.ok)) return;
  try {
    const r = await api('POST', '/orders', { city: CITY.id, pick: ui.pick[2], drop: ui.drop[2], tariff: ui.tariff });
    if (!r.ok) { toast(r.error || 'Не удалось создать заказ'); return; }
    ui.order = Object.assign(r.order, { pickN: ui.pick, dropN: ui.drop, tripRoute: r.tripRoute }); ui.ph = 'search'; render();
  } catch (e) { toast('Нет связи с сервером'); }
}
function cancelOrder() { const o = ui.order; if (o) api('DELETE', '/orders/' + o.id).catch(() => {}); ui.order = null; render(); }
function rateTrip(n) { const o = ui.order; if (!o) return; o.r = n; render(); api('POST', '/trips/' + o.id + '/rating', { rating: n }).catch(() => {}); }
async function loadTrips() { try { hist = await api('GET', '/trips'); } catch (e) {} if (ui.page === 'trips') render(); }
async function loadReviews() { try { reviews = await api('GET', '/reviews'); } catch (e) {} if (ui.page === 'reviews') render(); }
async function loadFaq() { if (FAQ.length) return; try { FAQ = await api('GET', '/faq'); } catch (e) {} if (ui.page === 'support') render(); }
async function rsend() {
  if (!ui.rs) return;
  try { await api('POST', '/reviews', { name: cfg.name, rating: ui.rs, text: ui.rtext }); } catch (e) { return; }
  ui.rs = 0; ui.rtext = ''; loadReviews();
}
async function csend() {
  const i = $('#ct'); if (!i || !i.value.trim()) return;
  const t = i.value.trim(); chat.push({ t }); render(); const n = $('#ct'); if (n) n.focus();
  try { const r = await api('POST', '/support', { message: t }); chat.push({ b: 1, t: r.reply }); } catch (e) { chat.push({ b: 1, t: 'Сервер недоступен, попробуйте позже.' }); }
  if (ui.page === 'support') render();
}

// --- отрисовка панели
function render() {
  const o = ui.order, p = $('#pb');
  document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('on', b.dataset.page === ui.page));
  if (ui.page !== 'home') { p.innerHTML = PAGES[ui.page](); if (ui.page === 'support') p.scrollTop = p.scrollHeight; upd(); return; }
  if (!o) p.innerHTML = `<div class="hd"><h1>Жёлтый</h1><button class="chip" data-act="theme" aria-label="Сменить тему">${isDark() ? '☀️ Светлая' : '🌙 Тёмная'}</button></div><p class="sub">Привет, ${esc(cfg.name)}. Нажмите на перекрёсток: сначала «откуда», потом «куда» (от 4 кварталов).</p>
<div class="chips">${POIS.map((q, i) => q.m ? '' : `<button class="chp" data-poi="${i}">${q.e} ${q.n}</button>`).join('')}</div><div class="chips">${CATS.map(c => `<button class="chp" data-cat="${c[0]}">${c[1]} ${c[2]}</button>`).join('')}</div>
<div class="pt"><i></i><span id="la"></span></div><div class="pt"><i class="b"></i><span id="lb"></span></div>
<div class="tfs">${Object.entries(TF).map(([k, v]) => `<button class="tf" data-t="${k}"><b>${v.n}</b><span id="p_${k}">—</span></button>`).join('')}</div>
<p class="legend">🔴 пробка · 🟠 затор · 🚧 перекрыто</p><p class="note" id="nt"></p><button class="go" id="go" data-act="go">Заказать</button>${ui.pick ? '<button class="lnk" data-act="reset">Сбросить точки</button>' : ''}`;
  else if (o.phase === 'search') p.innerHTML = `<h1>Ищем водителя</h1><div class="bar ind"><i></i></div><p class="note" id="nt"></p><button class="go" data-act="cancel">Отменить заказ</button>`;
  else if (o.phase === 'done' || o.phase === 'cancelled') p.innerHTML = `<h1>Вы приехали</h1><p class="sub">${label(o.dropN)}</p><div class="price">${o.price} ₽ · ${cfg.pay}</div><p class="note">Оцените поездку</p><div class="rs">${[1, 2, 3, 4, 5].map(n => `<button class="st${(o.r || 0) >= n ? ' on' : ''}" data-rate="${n}" aria-label="Оценка ${n}">★</button>`).join('')}</div><button class="go" data-act="new">Новая поездка</button>`;
  else {
    const c = o.driver, k = o.phase === 'pick' ? 1 : o.phase === 'board' ? 2 : 3;
    p.innerHTML = `<div class="drv"><div class="av">${c.name[0]}</div><div><b>${c.name}</b> ★ ${c.rate}<br><small>${c.model} · ${c.plate}</small></div></div>
<ol class="stp">${STEPS.map((s, i) => `<li class="${i < k ? 'done' : i === k ? 'cur' : ''}">${s}</li>`).join('')}</ol>
<div class="bar"><i id="pg"></i></div><p class="note" id="eta"></p>
<h3>Маршрут</h3><ol class="legs">${o.legs.map(l => `<li>${l}</li>`).join('')}</ol>
<div class="price">${o.price} ₽</div><button class="lnk" data-act="cancel">Отменить заказ</button>`;
  }
  upd();
}
function upd() {
  updHud(); if (ui.page !== 'home') return;
  const o = ui.order, g = id => document.getElementById(id);
  if (!o) {
    g('la').textContent = ui.pick ? 'Откуда: ' + label(ui.pick) : 'Откуда: нажмите на карту';
    g('lb').textContent = ui.drop ? 'Куда: ' + label(ui.drop) : 'Куда: нажмите на карту';
    const q = ui.quote, d = ui.pick && ui.drop;
    for (const k in TF) { g('p_' + k).textContent = d && q && q.prices ? q.prices[k] + ' ₽' : '—'; document.querySelector(`[data-t=${k}]`).classList.toggle('on', ui.tariff === k); }
    g('go').disabled = !(d && q && q.ok);
    g('nt').textContent = !ui.pick ? '' : q ? (q.eta ? `Ближайшая машина — ${q.eta} мин${q.surge > 1 ? ` · спрос ×${q.surge.toFixed(1)}` : ''}` : 'Сейчас все машины заняты') : 'Считаем маршрут…';
  } else if (o.phase === 'search') {
    g('nt').textContent = o.wait > 4 ? 'Все машины заняты — продолжаем искать' : 'Подбираем ближайшую машину';
  } else if (['pick', 'board', 'trip'].includes(o.phase)) {
    const ph = o.phase;
    g('eta').textContent = ph === 'pick' ? `Водитель приедет через ${o.eta} мин` : ph === 'board' ? 'Водитель на месте — садитесь' : `${o.eta} мин до места`;
    g('pg').style.width = Math.round(o.progress * 100) + '%';
    document.querySelectorAll('.legs li').forEach((li, i) => li.className = ph === 'trip' ? (i < o.legIndex ? 'done' : i === o.legIndex ? 'cur' : '') : '');
  }
}

// --- переключение города
function initCity(k) {
  const c = CITIES[k]; CITY = c; cityIdx = k; POIS = c.POIS; STOPS = c.STOPS;
  NAMED = new Map([...POIS, ...STOPS].map(p => [p.nd[2], p.n]));
  ui.order = null; ui.pick = ui.drop = null; ui.quote = null; ui.page = 'home'; ui.ph = null;
  cam = { z: 1, x: 0, y: 0 }; resize(); render(); connect(c.id); $('#cities').textContent = '📍 ' + c.n;
}

// --- события панели
$('#panel').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return; const o = ui.order, d = b.dataset;
  if (d.page) { ui.page = d.page; render(); ({ trips: loadTrips, reviews: loadReviews, support: loadFaq })[d.page]?.(); }
  else if (d.set) { const [k, v] = d.set.split(':'); if (k === 'notify') cfg.notify = !cfg.notify; else cfg[k] = v; if (k === 'theme') applyTheme(); saveCfg(); render(); }
  else if (d.rs) { ui.rs = +d.rs; render(); }
  else if (d.rate) rateTrip(+d.rate);
  else if (d.rep !== undefined) { if (!o) { const h = hist[+d.rep]; ui.pick = CITY.N[h.a]; ui.drop = CITY.N[h.b]; ui.page = 'home'; ui.quote = null; render(); fetchQuote(); } }
  else if (d.cat) {
    const ref = ui.pick || [11, 7], L = POIS.filter(q => q.cat === d.cat).sort((a, b) => hyp(a.x - ref[0], a.y - ref[1]) - hyp(b.x - ref[0], b.y - ref[1])), q = L[(ui.ci[d.cat] || 0) % L.length];
    ui.ci[d.cat] = (ui.ci[d.cat] || 0) + 1; if (q) { setPoint(q.nd); focus(q.nd); }
  }
  else if (d.poi !== undefined) { const q = POIS[+d.poi]; setPoint(q.nd); focus(q.nd); }
  else if (d.t) { ui.tariff = d.t; upd(); }
  else if (d.act === 'go') startOrder();
  else if (d.act === 'reset') { ui.pick = ui.drop = null; ui.quote = null; render(); }
  else if (d.act === 'cancel') cancelOrder();
  else if (d.act === 'new') { ui.order = null; ui.pick = ui.drop = null; ui.quote = null; render(); }
  else if (d.act === 'theme') { cfg.theme = isDark() ? 'light' : 'dark'; applyTheme(); saveCfg(); render(); }
  else if (d.act === 'rsend') rsend();
  else if (d.act === 'csend') csend();
});
$('#panel').addEventListener('input', e => { const t = e.target; if (t.id === 'nm') { cfg.name = t.value.trim() || 'Гость'; saveCfg(); } else if (t.id === 'rt') ui.rtext = t.value; });
$('#panel').addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.id === 'ct') csend(); });
$('#rush').addEventListener('click', () => { if (CITY) api('POST', `/cities/${CITY.id}/rush`, { on: !stats.rush }).catch(() => {}); });

// --- опрос состояния заказа (≈2,5 раза в секунду)
setInterval(() => {
  const o = ui.order; if (!o || o.phase === 'done' || o.phase === 'cancelled' || o.polling) return;
  o.polling = 1;
  api('GET', '/orders/' + o.id).then(v => {
    if (ui.order !== o) return; const prev = o.phase; Object.assign(o, v);
    if (v.phase !== prev) { phToast(o); refresh(); } else if (ui.page === 'home') upd();
  }).catch(() => {}).finally(() => { o.polling = 0; });
}, 400);
setInterval(() => { upd(); if (!ui.order && ui.pick && ui.page === 'home') fetchQuote(); }, 3000);
