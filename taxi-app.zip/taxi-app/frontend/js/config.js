// Общие константы, настройки пользователя и глобальное состояние интерфейса.
const $ = s => document.querySelector(s);
const PI = Math.PI, hyp = Math.hypot;
const man = (a, b) => hyp(a[0] - b[0], a[1] - b[1]) * 1.3;   // оценка расстояния (как на сервере)
const TF = { eco: { n: 'Эконом' }, comf: { n: 'Комфорт' }, biz: { n: 'Бизнес' } };
const CATS=[['school','🏫','Школы'],['museum','🏺','Музеи'],['court','⚖️','Суды'],['shop','🛒','Магазины'],['mall','🏬','ТЦ'],['hotel','🏨','Отели'],['food','🍽️','Рестораны']];
const cfg={theme:'auto',speed:1,pay:'Карта',notify:true,name:'Гость'};
const saveCfg=()=>{try{localStorage.setItem('zh_cfg',JSON.stringify(cfg))}catch(e){}};
function loadCfg(){try{Object.assign(cfg,JSON.parse(localStorage.getItem('zh_cfg')||'{}'))}catch(e){}}
const isDark=()=>cfg.theme==='dark'||(cfg.theme==='auto'&&matchMedia('(prefers-color-scheme: dark)').matches);
function applyTheme(){const r=document.documentElement;if(cfg.theme==='auto')r.removeAttribute('data-theme');else r.dataset.theme=cfg.theme;readCss()}
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const star=n=>'★'.repeat(n)+'☆'.repeat(5-n);
const STEPS=['Водитель найден','Едет к вам','Посадка','В пути'];

// Глобальное состояние (заполняется в ui.js / api.js)
const ui = { pick: null, drop: null, tariff: 'eco', order: null, page: 'home', rs: 0, rtext: '', ph: null, quote: null, ci: {} };
let CITIES = [], CITY = null, cityIdx = 0, started = false, POIS = [], STOPS = [], NAMED = new Map();
const cars = new Map();                                   // машины из потока сервера
let stats = { free: 0, total: 0, surge: 1, rush: false };
let hist = [], reviews = [], FAQ = [], chat = [{ b: 1, t: 'Здравствуйте! Я помощник Жёлтого. Чем помочь?' }];
const label = n => NAMED.get(n[2]) || CITY.names[CITY.nn[n[2]]] || 'проезд';
