// Главное меню: анимированное небо (солнце/луна, облака, шары), выбор города и миниатюры карт.
let menuOpen=true,mp={x:0,y:0,sx:0,sy:0,px:-999,py:-999},clouds=[],balloons=[],sparks=[],thumbs=[];
function thumb(cv2,c){const g=cv2.getContext('2d'),s=240/22,X=x=>x*s,Y=y=>y*s;g.clearRect(0,0,240,150);
 const gr=g.createLinearGradient(0,0,0,150);gr.addColorStop(0,css.s1);gr.addColorStop(1,css.s3);g.fillStyle=gr;g.fillRect(0,0,240,150);
 g.save();g.beginPath();c.tile.forEach((q,i)=>i?g.lineTo(X(q[0]),Y(q[1])):g.moveTo(X(q[0]),Y(q[1])));g.closePath();g.fillStyle=css.block;g.fill();g.clip();g.lineCap='round';g.lineJoin='round';
 for(const[pts,w]of c.water){g.beginPath();pts.forEach((q,i)=>i?g.lineTo(X(q[0]),Y(q[1])):g.moveTo(X(q[0]),Y(q[1])));g.strokeStyle=css.water;g.lineWidth=w*s;g.stroke()}
 g.fillStyle=css.park;c.parks.forEach(([x,y,rx,ry])=>{g.beginPath();g.ellipse(X(x),Y(y),rx*s,ry*s,0,0,7);g.fill()});
 const P2=(L,w,col)=>{g.beginPath();for(const e of L){const a=c.N[e.a],b=c.N[e.b];g.moveTo(X(a[0]),Y(a[1]));g.lineTo(X(b[0]),Y(b[1]))}g.strokeStyle=col;g.lineWidth=w;g.stroke()};
 P2(c.e2,s*.1,css.ink);P2(c.e1,s*.2,css.ink);P2(c.tm,s*.1,'#f0a93b');P2(c.th,s*.12,'#d9453a');g.restore()}
function buildMenu(){const c=$('#cards');
 c.innerHTML=CITIES.map((x,k)=>`<button class="cc" data-city="${k}" style="animation-delay:${k*.08}s"><canvas width="240" height="150"></canvas><b>${x.e} ${x.n}</b><small>${x.d}</small><span>${x.POIS.length} мест · пробок: ${x.nTraf} · перекрыто: ${x.closedE.length}</span></button>`).join('');
 thumbs=[...c.querySelectorAll('canvas')];
 clouds=Array.from({length:10},(_,i)=>({x:Math.random(),y:.06+Math.random()*.55,s:.6+Math.random()*.9,v:.004+Math.random()*.008,l:i%3,sq:0,ox:0,oy:0,px:0,py:0,r:30})).sort((a,b)=>a.l-b.l);
 balloons=[{x:.14,y:.42,c:'#F2A65A',t:0,b:0,px:0,py:0},{x:.86,y:.3,c:'#8E6BB0',t:2,b:0,px:0,py:0}];
 c.onclick=e=>{const b=e.target.closest('[data-city]');if(b)openCity(+b.dataset.city)};
 $('#cont').onclick=()=>{mp.px=mp.py=-999;mp.x=mp.y=0;menuOpen=false;$('#menu').style.display='none'};
 const M=$('#menu');
 M.addEventListener('pointermove',e=>{mp.x=e.clientX/innerWidth*2-1;mp.y=e.clientY/innerHeight*2-1;mp.px=e.clientX;mp.py=e.clientY});
 M.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;let h=0;
  for(const c2 of clouds)if(Math.hypot(e.clientX-c2.px,e.clientY-c2.py)<c2.r*1.7){c2.sq=1;boom(c2.px,c2.py);h=1}
  for(const b of balloons)if(Math.hypot(e.clientX-b.px,e.clientY-b.py)<40){b.b=140;boom(b.px,b.py);h=1}
  if(!h)boom(e.clientX,e.clientY)})}
const boom=(x,y)=>{for(let i=0;i<12;i++){const a=Math.random()*6.28,v=40+Math.random()*100;sparks.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-30,l:1})}};
function openCity(k){initCity(k);started=true;mp.px=mp.py=-999;mp.x=mp.y=0;menuOpen=false;$('#menu').style.display='none';toast('Добро пожаловать: '+CITIES[k].n)}
function showMenu(){menuOpen=true;$('#menu').style.display='block';$('#cont').style.display=started?'block':'none';thumbs.forEach((t,k)=>thumb(t,CITIES[k]))}
$('#cities').onclick=showMenu;
const stars=Array.from({length:70},()=>({x:Math.random(),y:Math.random()*.7,r:Math.random()*1.4+.4,p:Math.random()*6}));
function drawSky(g,w,h,T,dt){const dk=isDark(),gr=g.createLinearGradient(0,0,0,h);gr.addColorStop(0,css.s1);gr.addColorStop(.55,css.s2);gr.addColorStop(1,css.s3);g.globalAlpha=1;g.fillStyle=gr;g.fillRect(0,0,w,h);
 mp.sx+=(mp.x-mp.sx)*.06;mp.sy+=(mp.y-mp.sy)*.06;
 if(dk)for(const s of stars){g.globalAlpha=.35+.5*Math.abs(Math.sin(T*.8+s.p));g.fillStyle='#F3E9DC';g.beginPath();g.arc(s.x*w-mp.sx*6,s.y*h,s.r,0,7);g.fill()}
 g.globalAlpha=1;const sx=w*.78-mp.sx*18,sy=h*.17-mp.sy*10,r=Math.min(w,h)*.06;
 if(dk){const gl=g.createRadialGradient(sx,sy,r*.8,sx,sy,r*3);gl.addColorStop(0,'rgba(243,233,220,.35)');gl.addColorStop(1,'rgba(243,233,220,0)');g.fillStyle=gl;g.beginPath();g.arc(sx,sy,r*3,0,7);g.fill();
  g.fillStyle='#F3E9DC';g.beginPath();g.arc(sx,sy,r,0,7);g.fill();g.fillStyle='rgba(120,100,140,.25)';[[-.3,-.2,.22],[.25,.15,.3],[-.1,.4,.15]].forEach(([a,b,m])=>{g.beginPath();g.arc(sx+a*r,sy+b*r,m*r,0,7);g.fill()})}
 else{g.save();g.translate(sx,sy);g.rotate(T*.1);g.fillStyle=css.accent;g.globalAlpha=.35;for(let i=0;i<12;i++){g.rotate(PI/6);g.fillRect(r*1.3,-3,r*.7,6)}g.restore();g.globalAlpha=1;g.fillStyle=css.accent;g.beginPath();g.arc(sx,sy,r,0,7);g.fill()}
 for(const c of clouds){c.x+=c.v*dt;if(c.x>1.25)c.x=-.25;c.ox*=.94;c.oy*=.94;
  const px=c.x*w-mp.sx*(10+c.l*16)+c.ox,py=c.y*h-mp.sy*(6+c.l*10)+c.oy,r2=24*c.s*(1+c.l*.25),dx=px-mp.px,dy=py-mp.py,dd=hyp(dx,dy);
  if(dd<150&&dd>1){c.ox+=dx/dd*(150-dd)*.03;c.oy+=dy/dd*(150-dd)*.02}
  c.px=px;c.py=py;c.r=r2;c.sq*=.95;const sc=1+c.sq*.3*Math.sin(T*16),pas=dk?[['#6a5585',.45,-.12,-.16],[css.cl,.88,0,0]]:[[css.cl,.6+c.l*.13,0,0]];
  for(const[col,al,ax,ay]of pas){g.save();g.translate(px+ax*r2,py+ay*r2);g.scale(sc,2-sc);g.globalAlpha=al;g.fillStyle=col;g.beginPath();
   [[0,0,1],[.9,-.3,.8],[-.9,0,.7],[1.7,.1,.55],[-1.6,.2,.5]].forEach(([a,b,m])=>{g.moveTo(a*r2+m*r2,b*r2);g.arc(a*r2,b*r2,m*r2,0,7)});g.fill();g.restore()}}
 g.globalAlpha=1}
function sky(t,dt){const k=$('#sky'),d=devicePixelRatio||1,w=k.clientWidth,h=k.clientHeight;if(k.width!==(w*d|0)){k.width=w*d;k.height=h*d}
 const g=k.getContext('2d');g.setTransform(d,0,0,d,0,0);g.clearRect(0,0,w,h);drawSky(g,w,h,t/1000,dt);const T=t/1000;
 for(let l=0;l<3;l++){g.fillStyle=css.park;g.globalAlpha=.3+.22*l;g.beginPath();g.moveTo(0,h);const y0=h*(.78+l*.07);for(let x=0;x<=w+12;x+=12)g.lineTo(x,y0+Math.sin(x*.004*(1+l*.5)+l*2+mp.sx*.4)*h*.035-mp.sx*(4+l*6));g.lineTo(w,h);g.fill()}
 g.globalAlpha=1;
 for(const b of balloons){b.t+=dt;b.b*=.97;const x=b.x*w-mp.sx*22+Math.sin(T*.5+b.t)*14,y=b.y*h-mp.sy*12+Math.sin(T*.9+b.t)*10-b.b;b.px=x;b.py=y;
  g.fillStyle=b.c;g.beginPath();g.ellipse(x,y,22,28,0,0,7);g.fill();g.fillStyle=css.accent;g.globalAlpha=.7;g.beginPath();g.ellipse(x,y,8,28,0,0,7);g.fill();g.globalAlpha=1;
  g.strokeStyle=css.ink;g.lineWidth=1;g.beginPath();g.moveTo(x-14,y+22);g.lineTo(x-6,y+38);g.moveTo(x+14,y+22);g.lineTo(x+6,y+38);g.stroke();g.fillStyle=css.ink;g.fillRect(x-7,y+38,14,9)}
 for(let i=sparks.length-1;i>=0;i--){const p=sparks[i];p.l-=dt*1.3;if(p.l<=0){sparks.splice(i,1);continue}p.vy+=90*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;g.globalAlpha=p.l;g.fillStyle=css.accent;g.beginPath();g.arc(p.x,p.y,2+p.l*3,0,7);g.fill()}
 g.globalAlpha=1}
