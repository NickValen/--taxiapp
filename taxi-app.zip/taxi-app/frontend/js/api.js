// Клиент REST API и потока событий (SSE).
const API = '/api';
const CID = (() => { try { return localStorage.zh_cid || (localStorage.zh_cid = Math.random().toString(36).slice(2) + Date.now().toString(36)); } catch (e) { return 'anon'; } })();

const api = (method, path, body) => fetch(API + path, {
  method, headers: { 'Content-Type': 'application/json', 'X-Client-Id': CID }, body: body ? JSON.stringify(body) : undefined
}).then(r => { if (r.status >= 500) throw new Error('server error'); return r.json(); });

// Превращает компактный JSON сервера в структуры для отрисовки.
function decorate(c) {
  c.N = c.N.map((p, i) => [p[0], p[1], i]);
  const ed = c.E.map(([a, b, k, f, x]) => ({ a, b, c: k, f, x }));
  c.e1 = ed.filter(e => e.c === 1); c.e2 = ed.filter(e => e.c !== 1);
  c.th = ed.filter(e => e.f >= 2.5); c.tm = ed.filter(e => e.f > 1.4 && e.f < 2.5);
  c.closedE = c.closed.map(z => ({ g: z.g.map(([a, b]) => ({ a, b })), p: z.p }));
  const obj = p => { const nd = c.N[p.nd]; return { ...p, x: nd[0], y: nd[1], nd }; };
  c.POIS = c.POIS.map(obj); c.STOPS = c.STOPS.map(obj);
  c.bld = [[], [], []]; c.nTraf = c.stats.traf;
}
async function loadCities() {
  const list = await api('GET', '/cities');
  CITIES = await Promise.all(list.map(s => api('GET', '/cities/' + s.id)));
  CITIES.forEach(decorate);
}

// Поток позиций машин выбранного города (≈10 раз в секунду).
let stream = null;
function connect(id) {
  if (stream) stream.close();
  cars.clear();
  stream = new EventSource(API + '/cities/' + id + '/stream');
  stream.onmessage = e => {
    const d = JSON.parse(e.data), now = performance.now(), seen = new Set();
    stats = { free: d.free, total: d.total, surge: d.surge, rush: d.rush };
    for (const [i, x, y, a, v, st] of d.cars) {
      seen.add(i); let c = cars.get(i); if (!c) cars.set(i, c = { id: i });
      Object.assign(c, { x0: x, y0: y, a, v, st, t0: now });
    }
    cars.forEach((c, i) => { if (!seen.has(i)) cars.delete(i); });
    if (typeof updHud === 'function') updHud();
  };
}
