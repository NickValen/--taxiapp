// Отрисовка карты на canvas, камера (перетаскивание, масштаб), подсказки и клики.
const cv = $('#map'), cx = cv.getContext('2d');
let css = {}, vw = 0, vh = 0, S = 1, ox = 0, oy = 0, cam = { z: 1, x: 0, y: 0 }, rc = { x: 0, y: 0 }, drag = 0;

function readCss(){const s=getComputedStyle(document.documentElement);['bg','road','block','park','water','ink','busy','accent','cl','s1','s2','s3'].forEach(k=>css[k]=s.getPropertyValue('--'+k).trim())}
function resize(){const r=cv.getBoundingClientRect(),d=devicePixelRatio||1;vw=r.width;vh=r.height;cv.width=vw*d;cv.height=vh*d;cx.setTransform(d,0,0,d,0,0);
 const mob=vw<=760,x0=(mob?0:392)+12,y0=56,w=vw-x0-12,h=vh-y0-(mob?vh*.46+8:12);
 const[bx0,by0,bx1,by1]=CITY.bb;S=Math.max(20,Math.min(w/(bx1-bx0+.9),h/(by1-by0+.9)));ox=x0+(w-S*(bx1-bx0))/2-bx0*S;oy=y0+(h-S*(by1-by0))/2-by0*S;rc={x:x0+w/2,y:y0+h/2}}
const P=(x,y)=>[ox+x*S,oy+y*S];
function rr(x,y,w,h,r){cx.beginPath();cx.roundRect(x,y,w,h,r);cx.fill()}
function line(pts,dash){cx.beginPath();pts.forEach((q,i)=>{const[a,b]=P(q[0],q[1]);i?cx.lineTo(a,b):cx.moveTo(a,b)});cx.setLineDash(dash||[]);cx.stroke();cx.setLineDash([])}
function pin(n,kind){const[x,y]=P(n[0],n[1]),r=S*.14;cx.lineWidth=3;cx.strokeStyle=css.ink;if(kind==='a'){cx.fillStyle=css.accent;cx.beginPath();cx.arc(x,y,r,0,7);cx.fill();cx.stroke()}else{cx.fillStyle=css.ink;rr(x-r,y-r,r*2,r*2,r*.3);cx.fillStyle=css.road;rr(x-r*.4,y-r*.4,r*.8,r*.8,2)}}

const tilePath=()=>{cx.beginPath();CITY.tile.forEach((q,i)=>{const[x,y]=P(q[0],q[1]);i?cx.lineTo(x,y):cx.moveTo(x,y)});cx.closePath()};
function mapLayer(){const C=CITY,N=C.N,pth=L=>{cx.beginPath();for(const e of L){const a=N[e.a],b=N[e.b];cx.moveTo(ox+a[0]*S,oy+a[1]*S);cx.lineTo(ox+b[0]*S,oy+b[1]*S)}};
 tilePath();cx.save();cx.shadowColor='rgba(40,25,10,.4)';cx.shadowBlur=S*.7;cx.shadowOffsetY=S*.3;cx.fillStyle=css.block;cx.fill();cx.restore();
 cx.save();tilePath();cx.clip();cx.lineCap='round';cx.lineJoin='round';
 for(const[pts,w]of C.water){cx.strokeStyle=css.water;cx.globalAlpha=.4;cx.lineWidth=S*(w+.2);line(pts);cx.globalAlpha=1;cx.lineWidth=S*w;line(pts)}
 cx.fillStyle=css.block;for(const[x,y,rx,ry]of C.isl){const[a,b]=P(x,y);cx.beginPath();cx.ellipse(a,b,rx*S,ry*S,0,0,7);cx.fill()}
 cx.fillStyle=css.accent;cx.globalAlpha=.13;for(const[x,y,rx,ry]of C.zones){const[a,b]=P(x,y);cx.beginPath();cx.ellipse(a,b,rx*S,ry*S,0,0,7);cx.fill()}cx.globalAlpha=1;
 cx.fillStyle=css.park;for(const[x,y,rx,ry]of C.parks){const[a,b]=P(x,y);cx.beginPath();cx.ellipse(a,b,rx*S,ry*S,0,0,7);cx.fill()}
 cx.fillStyle='#5f8f57';cx.globalAlpha=.6;cx.beginPath();for(const[x,y]of C.trees){const[a,b]=P(x,y);cx.moveTo(a+S*.07,b);cx.arc(a,b,S*.07,0,7)}cx.fill();
 cx.fillStyle=css.ink;for(let g=0;g<3;g++){cx.globalAlpha=.07+g*.04;cx.beginPath();for(const[x,y,w,h,c,s]of C.bld[g])[[-1,-1],[1,-1],[1,1],[-1,1]].forEach(([u,v],i)=>{u*=w/2;v*=h/2;const X=ox+(x+u*c-v*s)*S,Y=oy+(y+u*s+v*c)*S;i?cx.lineTo(X,Y):cx.moveTo(X,Y)});cx.fill()}
 cx.strokeStyle=css.ink;cx.globalAlpha=.2;cx.lineWidth=S*.2;pth(C.e2);cx.stroke();cx.lineWidth=S*.3;pth(C.e1);cx.stroke();
 cx.globalAlpha=1;cx.strokeStyle=css.road;cx.lineWidth=S*.13;pth(C.e2);cx.stroke();cx.lineWidth=S*.22;pth(C.e1);cx.stroke();
 cx.globalAlpha=.85;cx.lineWidth=S*.09;cx.strokeStyle='#f0a93b';pth(C.tm);cx.stroke();cx.strokeStyle='#d9453a';pth(C.th);cx.stroke();cx.globalAlpha=1;
 for(const z of C.closedE){cx.strokeStyle=css.block;cx.lineWidth=S*.2;pth(z.g);cx.stroke();cx.strokeStyle='#d9453a';cx.lineWidth=S*.07;cx.setLineDash([S*.1,S*.1]);pth(z.g);cx.stroke();cx.setLineDash([])}
 cx.textAlign='center';cx.textBaseline='middle';cx.fillStyle=css.ink;cx.font=`${S*.34}px sans-serif`;for(const z of C.closedE){const[x,y]=P(z.p[0],z.p[1]);cx.fillText('🚧',x,y)}
 cx.font=`${S*.28}px sans-serif`;for(const q of STOPS){const[x,y]=P(q.x+.12,q.y-.12);cx.fillText(q.e,x,y)}
 for(const pass of[1,0])for(const q of POIS){if((q.m?1:0)!==pass)continue;const[x,y]=P(q.x,q.y),mn=q.m;cx.fillStyle=css.road;cx.strokeStyle=mn?css.busy:css.accent;cx.lineWidth=mn?1.8:2.5;cx.beginPath();cx.arc(x,y,S*(mn?.19:.28),0,7);cx.fill();cx.stroke();cx.fillStyle=css.ink;cx.font=`${S*(mn?.24:.34)}px sans-serif`;cx.fillText(q.e,x,y+1);
  if(S*cam.z>(mn?46:30)){cx.font=`700 ${S*(mn?.14:.16)}px Manrope,sans-serif`;cx.strokeStyle=css.road;cx.lineWidth=3;cx.strokeText(q.n,x,y+S*(mn?.36:.5));cx.fillText(q.n,x,y+S*(mn?.36:.5))}}
 if(S*cam.z>26){cx.font=`600 ${S*.15}px Manrope,sans-serif`;cx.textAlign='center';for(const l of C.labels){const[x,y]=P(l.x,l.y);cx.save();cx.translate(x,y);cx.rotate(l.a);cx.lineWidth=3;cx.strokeStyle=l.w?css.water:css.road;cx.fillStyle=l.w?(isDark()?'#bcd3e6':'#3f6f95'):css.ink;cx.globalAlpha=l.w?1:.75;cx.strokeText(l.t,0,0);cx.fillText(l.t,0,0);cx.restore()}cx.globalAlpha=1}
 cx.restore();tilePath();cx.strokeStyle=css.road;cx.lineWidth=S*.1;cx.stroke()}

function draw(t, dt) {
  cx.clearRect(0, 0, vw, vh); drawSky(cx, vw, vh, t / 1000, dt || .016);
  if (!CITY) return;
  cx.save(); cx.translate(cam.x, cam.y); cx.scale(cam.z, cam.z); cx.globalAlpha = 1;
  mapLayer();
  const o = ui.order, now = performance.now();
  cx.lineCap = 'round'; cx.lineJoin = 'round';
  if (!o && ui.pick && ui.drop && ui.quote && ui.quote.path) { cx.strokeStyle = css.ink; cx.lineWidth = 4; line(ui.quote.path, [2, 9]); }
  if (o && ['search', 'pick', 'board'].includes(o.phase) && o.tripRoute) { cx.strokeStyle = css.ink; cx.globalAlpha = .3; cx.lineWidth = 4; line(o.tripRoute); cx.globalAlpha = 1; }
  if (o && o.phase === 'pick' && o.route) { cx.strokeStyle = css.ink; cx.globalAlpha = .5; cx.lineWidth = 4; line(o.route, [2, 9]); cx.globalAlpha = 1; }
  if (o && o.phase === 'trip' && o.route) { cx.strokeStyle = css.accent; cx.lineWidth = 9; line(o.route); cx.strokeStyle = css.ink; cx.lineWidth = 3.5; line(o.route); }
  if (o && o.phase === 'search') { const [x, y] = P(o.pickN[0], o.pickN[1]), k = (t / 900) % 1; cx.strokeStyle = css.accent; cx.globalAlpha = 1 - k; cx.lineWidth = 4; cx.beginPath(); cx.arc(x, y, S * .2 + S * .9 * k, 0, 7); cx.stroke(); cx.globalAlpha = 1; }
  const pk = o ? o.pickN : ui.pick, dr = o ? o.dropN : ui.drop;
  if (dr) pin(dr, 'b'); if (pk && !(o && o.phase === 'trip')) pin(pk, 'a');
  // машины: позиция экстраполируется от последнего снимка сервера
  for (const c of cars.values()) {
    const k = Math.min(.3, (now - c.t0) / 1000), [x, y] = P(c.x0 + Math.cos(c.a) * c.v * k, c.y0 + Math.sin(c.a) * c.v * k), L = S * .36, Wd = S * .18;
    cx.save(); cx.translate(x, y);
    if (o && o.driver && o.driver.id === c.id) { cx.strokeStyle = css.accent; cx.lineWidth = 3; cx.beginPath(); cx.arc(0, 0, S * .3, 0, 7); cx.stroke(); }
    cx.rotate(c.a); cx.fillStyle = c.st === 0 ? css.accent : css.busy; rr(-L / 2, -Wd / 2, L, Wd, Wd * .4);
    cx.fillStyle = 'rgba(46,42,59,.6)'; cx.fillRect(L * .02, -Wd * .38, L * .22, Wd * .76); cx.restore();
  }
  cx.restore();
}

function focus(n){cam.z=1.8;cam.x=rc.x-(ox+n[0]*S)*cam.z;cam.y=rc.y-(oy+n[1]*S)*cam.z}
function zoomAt(px,py,f){const nz=Math.min(3.5,Math.max(.7,cam.z*f));f=nz/cam.z;cam.x=px-(px-cam.x)*f;cam.y=py-(py-cam.y)*f;cam.z=nz}
const world=e=>{const r=cv.getBoundingClientRect();return[((e.clientX-r.left-cam.x)/cam.z-ox)/S,((e.clientY-r.top-cam.y)/cam.z-oy)/S]};
const hit=(wx,wy)=>POIS.find(q=>hyp(q.x-wx,q.y-wy)<(q.m?.3:.5))||STOPS.find(q=>hyp(q.x+.12-wx,q.y-.12-wy)<.28);
const nodeAt=(x,y)=>{let b=null,bd=1;for(const n of CITY.N){const d=hyp(n[0]-x,n[1]-y);if(d<bd){bd=d;b=n}}return b};
const ptr=new Map();
cv.addEventListener('pointerdown',e=>{cv.setPointerCapture(e.pointerId);ptr.set(e.pointerId,[e.clientX,e.clientY]);drag=0});
cv.addEventListener('pointermove',e=>{const r=cv.getBoundingClientRect(),tip=$('#tip');
 if(ptr.has(e.pointerId)){const o=ptr.get(e.pointerId),n=[e.clientX,e.clientY];
  if(ptr.size===1){drag+=Math.abs(n[0]-o[0])+Math.abs(n[1]-o[1]);if(drag>6){cam.x+=n[0]-o[0];cam.y+=n[1]-o[1]}}
  else{const q=[...ptr].find(([k])=>k!==e.pointerId)[1];drag=99;zoomAt((n[0]+q[0])/2-r.left,(n[1]+q[1])/2-r.top,Math.hypot(n[0]-q[0],n[1]-q[1])/Math.hypot(o[0]-q[0],o[1]-q[1]))}
  ptr.set(e.pointerId,n);tip.style.display='none'}
 else{const w=world(e),h=hit(w[0],w[1]);if(h){tip.textContent=h.e+' '+h.n;tip.style.left=e.clientX-r.left+14+'px';tip.style.top=e.clientY-r.top+14+'px';tip.style.display='block'}else tip.style.display='none'}});
['pointerup','pointercancel'].forEach(t=>cv.addEventListener(t,e=>ptr.delete(e.pointerId)));
cv.addEventListener('wheel',e=>{e.preventDefault();const r=cv.getBoundingClientRect();zoomAt(e.clientX-r.left,e.clientY-r.top,e.deltaY<0?1.15:1/1.15)},{passive:false});
$('#zi').onclick=()=>zoomAt(rc.x,rc.y,1.3);$('#zo').onclick=()=>zoomAt(rc.x,rc.y,1/1.3);$('#zr').onclick=()=>{cam={z:1,x:0,y:0}};
cv.addEventListener('click',e=>{if(drag>6)return;if(ui.page!=='home'){ui.page='home';render()}if(ui.order)return;const w=world(e),h=hit(w[0],w[1]);setPoint(h?h.nd:nodeAt(w[0],w[1]))});
