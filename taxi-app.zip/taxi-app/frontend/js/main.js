// Запуск приложения.
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', readCss);
addEventListener('resize', resize);

async function boot() {
  loadCfg(); applyTheme();
  try { await loadCities(); }
  catch (e) {
    document.body.insertAdjacentHTML('beforeend', '<div style="position:fixed;inset:0;display:grid;place-items:center;z-index:99;background:#1D1822;color:#F3E9DC;font:16px Manrope,sans-serif;text-align:center;padding:24px">Не удаётся связаться с сервером.<br>Запустите его командой <b>npm start</b> и обновите страницу.</div>');
    return;
  }
  buildMenu(); initCity(0); showMenu();
  let last = performance.now();
  (function loop(t) {
    const dt = Math.min(.05, (t - last) / 1000); last = t;
    if (menuOpen) sky(t, dt); else draw(t, dt);
    requestAnimationFrame(loop);
  })(last);
}
boot();
